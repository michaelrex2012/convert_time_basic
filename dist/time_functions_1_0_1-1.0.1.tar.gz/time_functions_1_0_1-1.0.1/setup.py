from setuptools import setup, find_packages

VERSION = '1.0.1'
DESCRIPTION = 'Simple functions for working with time'
LONG_DESCRIPTION = ("# time-functions-1.0.1"
                    "Functions for working with time. There aren't any dependencies yet."
                    "***"
                    "## Install and Update"
                    "Install this package with:"
                    "> python -m pip install time-functions-1.0.1")

setup(
    name="time-functions-1.0.1",
    version=VERSION,
    author="@michaelrex2012",
    author_email="<michaelgiu2012@outlook.com>",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=[],
    license="MIT",
    url="https://github.com/michaelrex2012/time-functions",

    keywords=['python', 'time', 'basic'],
    classifiers=[
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)
