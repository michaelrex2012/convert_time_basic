# time-functions v2.0
## Overview
Welcome to the time-functions github repo. This package helps you work time with functions.
## Installing
Simply install with:  
> python -m pip install time-functions


Keeping time-functions up to date is easy too:
> python -m pip install --upgrade time-functions


## Features
### Functions
- convertTime()
- stress()

See [wiki](https://github.com/michaelrex2012/time-functions/wiki) for more info!
