from time_functions import stress

stress(10000000, True)
